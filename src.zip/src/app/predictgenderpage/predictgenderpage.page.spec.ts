import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PredictgenderpagePage } from './predictgenderpage.page';

describe('PredictgenderpagePage', () => {
  let component: PredictgenderpagePage;
  let fixture: ComponentFixture<PredictgenderpagePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PredictgenderpagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
