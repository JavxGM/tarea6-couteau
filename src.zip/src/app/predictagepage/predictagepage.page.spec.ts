import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PredictagepagePage } from './predictagepage.page';

describe('PredictagepagePage', () => {
  let component: PredictagepagePage;
  let fixture: ComponentFixture<PredictagepagePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PredictagepagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
